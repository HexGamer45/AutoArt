To make it work add an image into this folder called "image.png", then run the exe file. That will make a file called
"imageCSVFile.csv". Then edit the "main.ahk" file changing the positions of each part and the size of the boxes. To
find the size of these boxes, go on paint or paint.net or any image editor, and then select the whole white part of
the box. Then divide the dimensions by 32, and whatever that value is, replace the lines as such:

boxSizeX:= 18.5 --> boxSizeX:= <first dimension value (x)>
boxSizeY:= 18.5 --> boxSizeY:= <second dimension value (y)>
do the same for all the positions: wheel, start, entry, exitter.

Then you can run the ahk file, then go onto your roblox window and hit F1, this will make the drawing start after
2 seconds. Hit F1 again to stop the process, however if you do pause it you should reopen the program and start again
instead of resuming, as some pixels may be missed otherwise.

--By HexGamer