from PIL import Image
import os, csv, random



def rgbToHex(pixel):
    if len(pixel) > 4: return "000000"
    totalHex = ""
    pixel = pixel[:3]
    for colour in pixel:
        newHex = hex(colour)[2:]
        if len(newHex) == 2:
            totalHex += newHex
        elif len(newHex) == 1:
                totalHex += "0" + newHex
        else:
            totalHex += "00"
    return totalHex
    

imageFile = "image.png"
file, ext = os.path.splitext(imageFile)

imageList = []
with Image.open(imageFile) as im:
    width, height = im.size
    for y in range(height):
        row = []
        for x in range(width):
            row.append(rgbToHex(im.getpixel((x,y))))
            #row.append(rgbToHex((random.randint(0,255),random.randint(0,255),random.randint(0,255))))
        imageList.append(row)
        
with open("imageCSVFile.csv", "w", newline = "") as csvfile:
    writer = csv.writer(csvfile, delimiter=",", quotechar="|")
    for row in imageList:
        writer.writerow(row)
        